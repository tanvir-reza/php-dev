<?php
	$db_host = "localhost";
	$db_user = "pylikcom_user";
	$db_pass = "Vpn2021$$";
	$db_name = "pylikcom_php-db";
	$conn = mysqli_connect($db_host, $db_user, $db_pass , $db_name);
    

?>